#
# Cookbook:: task1_community
# Recipe:: default
#
# Copyright:: 2018, Daniel Isakau, All Rights Reserved.

include_recipe 'nano'




